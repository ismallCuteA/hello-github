var pyq = {
  template: `
  <div class="box1" >
  <slot name="top"></slot>
  <slot name="middle"></slot>
  <slot name="bottom"></slot>

      
     
    </div>
  `
}

export {
  pyq
}