var firstName = "exceed our expectations 超出";
var lastName = "the government's transport  policy 运输 "
export {
  firstName,
  lastName
}