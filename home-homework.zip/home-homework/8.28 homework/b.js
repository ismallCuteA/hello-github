function print() {
  alert("it was not apparent 明显 to anyone else")
}
var a = 10 + "strengthen our immune system 免疫";
export {
  print
}

export default a